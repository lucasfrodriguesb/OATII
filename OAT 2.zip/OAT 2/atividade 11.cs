using System;

class Program
{
static void Main(string[] args)
{
Console.Write("Digite o preço de etiqueta do produto: ");
double precoEtiqueta = double.Parse(Console.ReadLine);

Console.WriteLine("Escolha a condição de pagamento:");
Console.WriteLine("1 - À vista em dinheiro ou cheque");
Console.WriteLine("2 - À vista no cartão de crédito");
Console.WriteLine("3 - Em duas vezes sem juros");
Console.WriteLine("4 - Em duas vezes com juros");

Console.Write("Digite o código da condição de pagamento: ");
int codigoCondicao = int.Parse(Console.ReadLine);

double valorPago;

switch (codigoCondicao)
{
case 1:
valorPago = precoEtiqueta * 0.9; // 10% de desconto
break;
case 2:
valorPago = precoEtiqueta * 0.85; // 15% de desconto
break;
case 3:
valorPago = precoEtiqueta; // preço normal de etiqueta sem juros
break;
case 4:
valorPago = precoEtiqueta * 1.1; // preço normal de etiqueta mais 10% de juros
break;
default:
Console.WriteLine("Condição de pagamento inválida.");
return;
}

Console.WriteLine("Valor a ser pago: " + valorPago.ToString("F2"));
}
}