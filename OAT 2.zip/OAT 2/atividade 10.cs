using System;

class Program
{
static void Main(string args)
{
Console.Write("Digite o peso em kg: ");
double peso = double.Parse(Console.ReadLine);

Console.Write("Digite a altura em metros: ");
double altura = double.Parse(Console.ReadLine);

double imc = peso / (altura * altura);
string condicao;

if (imc < 18.5)
{
condicao = "Abaixo do peso";
}
else if (imc >= 18.5 && imc < 25)
{
condicao = "Peso normal";
}
else if (imc >= 25 && imc < 30)
{
condicao = "Acima do peso";
}
else
{
condicao = "Obeso";
}
Console.WriteLine("Seu IMC é: " + imc.ToString("F2"));
Console.WriteLine("Condição: " + condicao);
}
}