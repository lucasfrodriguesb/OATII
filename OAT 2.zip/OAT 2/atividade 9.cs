using System;

class Program
{
static void Main(string[] args)
{
Console.Write("Digite sua altura em metros: ");
double altura = double.Parse(Console.ReadLine);

Console.Write("Digite seu sexo (M para masculino ou F para feminino): ");
char sexo = char.Parse(Console.ReadLine);

double pesoIdeal;

if (sexo == 'M' || sexo == 'm')
{
pesoIdeal = (72.7 * altura) - 58;
}
else if (sexo == 'F' || sexo == 'f')
{
pesoIdeal = (62.1 * altura) - 44.7;
}
else
{
Console.WriteLine("Sexo inválido.");
return; // Encerra o programa caso o sexo seja inválido
}
Console.WriteLine("Seu peso ideal é: " + pesoIdeal.ToString("F2") + " kg");
}
}