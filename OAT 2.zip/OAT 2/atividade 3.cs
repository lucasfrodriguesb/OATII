using system

class program
{
    stact void main(string args);
    {
        console.white("digite um numero: ");
        int numero = int.parse(console.Readline);

        if (numero %2 == 0)
        {
        console.whiteLine("o numerro e par ");
        }
        else
        {
            console.whiteLine("o numero e impar ");
        }

        
    }
}