using system

class program
{
    static void main(string args)
    {
        console.white("digite o valor A: ");
        int A =int.parse(console.Readline);

        console.white("digite o valor B: ");
        int B =int.parse(console.Readline);

        int C;

        if(A == B)
        {
            C = A + B;
        }
        else
        {
            C = A * B;
        }
        console.whiteline("valor de C e: " + C);
    }
}