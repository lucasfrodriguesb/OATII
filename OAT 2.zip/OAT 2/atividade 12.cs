using System;

class Program
{
static void Main(string[] args)
{
Console.Write("Digite o número de identificação do aluno: ");
int numeroAluno = int.Parse(Console.ReadLine);

Console.Write("Digite a nota da primeira verificação: ");
double nota1 = double.Parse(Console.ReadLine);

Console.Write("Digite a nota da segunda verificação: ");
double nota2 = double.Parse(Console.ReadLine);

Console.Write("Digite a nota da terceira verificação: ");
double nota3 = double.Parse(Console.ReadLine);

Console.Write("Digite a média dos exercícios: ");
double mediaExercicios = double.Parse(Console.ReadLine);

double mediaAproveitamento = (nota1 + nota2 * 2 + nota3 * 3 + mediaExercicios) / 7;

Console.WriteLine("Número do aluno: " + numeroAluno);
Console.WriteLine("Notas: " + nota1 + ", " + nota2 + ", " + nota3);
Console.WriteLine("Média dos exercícios: " + mediaExercicios);
Console.WriteLine("Média de aproveitamento: " +
mediaAproveitamento.ToString("F2"));

string conceito;
if (mediaAproveitamento >= 90)
conceito = "A";
else if (mediaAproveitamento >= 75)
conceito = "B";
else if (mediaAproveitamento >= 60)
conceito = "C";
else if (mediaAproveitamento >= 40)
conceito = "D";
else
conceito = "E";

Console.WriteLine("Conceito: " + conceito);

if (conceito == "A" || conceito == "B" || conceito == "C")
Console.WriteLine("Aprovado");
else
Console.WriteLine("Reprovado");
}
}