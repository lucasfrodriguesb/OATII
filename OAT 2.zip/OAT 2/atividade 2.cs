using system;

class program
{
    stact voidmain(string args)
    {
        console.white("digite o nome da pessoa: ");
        string nome = (console.ReadLine);

        console.white("digite o sexo da pessoa (m\f): ");

        char sexo = char.parse(console.ReadLine);

        console,white("digite o estado civil da pessoa: ");
        string estadocivil = (console.ReadLine):

        if (sexo == "f" && estadocivil == "CASADA")
{
    console.white("digite tempo de casada (anos): ");
    int tempocasada = in.parse(console.ReadLine);

    console.whiteline($ "a pessoa(nome) e casada ha (tempocasada) anos ");
    
}

    }
}