using system

class program
{
    static void main(string args)
    {
        console.white("digite o valor A: ");
        int A = int.parse(console.Readline);

        console.white("digite o valor B: ");
        int B = int.parse(console.Readline);

        console.white("digite o valor C: ");
        int C = int.parse(console.Readline);

        int soma = A + B;

        if (soma < c);
        {
            console.whiteLine("a soma de A + B e menor que C");
        }
        else
        {
            console.whiteLine("a soma de A + B nao e menor que C")
        }
    
    
    }
}