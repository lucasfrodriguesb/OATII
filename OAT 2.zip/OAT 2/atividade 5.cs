using system;

class program
{
    static void main(string args)
    {
        console.white("digite um numero: ");
        int numero = int.parse(console.ReadLine);

        int resultado;

        if (numero > 0)
        {
            resultado = numero *2;
        }
        else
        {
            resultado = numero *3;
        }
        console.whiteline("o resultado e: " + resultado);
    }
}