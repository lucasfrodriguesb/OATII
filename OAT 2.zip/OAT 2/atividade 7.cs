using System;

class Program
{
static void Main(string args)
{
Console.WriteLine("Digite um número inteiro:");
int numero = int.Parse(Console.ReadLine);

if (numero % 2 == 0)
{
// Se o número for par
int resultado = numero + 5;
Console.WriteLine("Resultado da soma: " + resultado);
}
else
{
// Se o número for ímpar

int resultado = numero + 8;
Console.WriteLine("Resultado da soma: " + resultado);
}
}
}