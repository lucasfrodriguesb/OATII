using System;

class Program
{
static void Main(string args)
{
Console.WriteLine("Digite três valores inteiros diferentes:");

Console.Write("Valor 1: ");
int valor1 = int.Parse(Console.ReadLine);

Console.Write("Valor 2: ");
int valor2 = int.Parse(Console.ReadLine);

Console.Write("Valor 3: ");
int valor3 = int.Parse(Console.ReadLine);

int maior, meio, menor;

// Verifica o maior valor
if (valor1 > valor2 && valor1 > valor3)
{
maior = valor1;
meio = valor2 > valor3 ? valor2 : valor3;
menor = valor2 > valor3 ? valor3 : valor2;
}
else if (valor2 > valor1 && valor2 > valor3)
{
maior = valor2;
meio = valor1 > valor3 ? valor1 : valor3;
menor = valor1 > valor3 ? valor3 : valor1;
}
else
{
maior = valor3;
meio = valor1 > valor2 ? valor1 : valor2;
menor = valor1 > valor2 ? valor2 : valor1;
}

Console.WriteLine("Valores em ordem decrescente: {0}, {1}, {2}", maior, meio, menor);
}
}